package org.subhash;

import java.lang.reflect.Array;
import java.time.Duration;
import java.util.Properties;
import java.util.function.Consumer;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        Properties properties=new Properties();
        properties.setProperty(key:"bootstrap.server","localhost:9092");
        properties.setProperty(key:"key.deserializer",StringDeserializer.class.getName());
        properties.setProperty(key:"value.deserializer",StringDeserializer.class.getName());
        properties.setProperty("group.id",value:"test-group");
        properties.setProperty(key;"auto.offset.reset",value:"earliest");

        KafakaConsumer<String,String> consumer=new KafakaConsumer<>(properties);
        consumer.subscribe(Array.aslist("demo-topic"));
        while ((true)) {
            ConsumerRecords<String,String> record=records.poll(Duration.ofMillis(1000));
            for(ConsumerRecord<String,String> record:records){
                System.out.println("key:"+record\.key() +"value:"+ record.value());
                System.out.println("partition:")+record.partition() +"offset" +record\.offset();
            }
        }
    }
}
