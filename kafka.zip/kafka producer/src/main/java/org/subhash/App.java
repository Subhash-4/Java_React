package org.subhash;

import java.util.Properties;

import org.apache.kafka.clients.producer.Callback;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.serialization.StringSerializer;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {

		Properties properties = new Properties();
		properties.setProperty("bootstrap.servers", "localhost:9092");
		properties.setProperty("key.serializer", StringSerializer.class.getName());
		properties.setProperty("value.serializer", StringSerializer.class.getName());

		KafkaProducer<String, String> produce = new KafkaProducer<>(properties);
		ProducerRecord<String, String> record = new ProducerRecord<String, String>("demo-topic", "mykey", "Nam Bengarulu");
		produce.send(record, new Callback() {

			@Override
			public void onCompletion(RecordMetadata metadata, Exception e) {
				if (e != null) {
					System.out.println("Tpoic :" + metadata.topic());
					System.out.println("partition:" + metadata.partition());
					System.out.println("offset:" + metadata.offset());
					System.out.println("timestamp:" + metadata.timestamp());

				} else {
					System.out.println("Error :" + e.getMessage());
				}
			}
		});
		produce.flush();
		produce.close();

	}

}
