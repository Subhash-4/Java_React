package org.subhash.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.subhash.entity.Location;
import org.subhash.service.LocationService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;


@RestController
@RequestMapping("/api/location")
public class LocationController {
@Autowired
	private LocationService locationService;

	
	
		
	
	
	@Override
public String toString() {
	return "LocationController [locationService=" + locationService + "]";
}

	@GetMapping
	public List<Location>getAll(){
		return locationService.getLocations();
	}

	@GetMapping("/{id}")
	public Location getById(@PathVariable int id) {
		return locationService.getLocationById(id);
	}
	
	
	@PostMapping
	public Location addLocation(@RequestBody Location location) {
		return locationService.addLocation(location);
	}
	@PutMapping("/{id}")
	
	public Location updateLocation(@PathVariable int id,@RequestBody Location location) {
		return locationService.addLocation(location);
				
	}
	@DeleteMapping("/{id}")
	public void deleteLocation(@PathVariable int id) {
		locationService.deleteLocation(id);
	}
}

