package org.subhash.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.subhash.entity.Supplier;
import org.subhash.service.SupplierService;

@RestController
@RequestMapping("/api/supplier")
public class SupplierController {
	@Autowired
	private SupplierService supplierService;

	@GetMapping
	public List<Supplier> getAll() {
		return supplierService.getSuppliers();
	}

	@GetMapping("/{id}")
	public Supplier getSupplierById(int id) {
		return supplierService.getSupplierById(id);
	}

	@PostMapping
	public Supplier addSuppliers(@RequestBody Supplier supplier) {
		return supplierService.addSupplier(supplier);
	}

	public SupplierController() {
		super();
		// TODO Auto-generated constructor stub
	}

	@PutMapping("/{id}")
	public Supplier updateSupplier(@PathVariable int id, @RequestBody Supplier supplier) {
		return supplierService.updateSupplier(id, supplier);
	}

	@DeleteMapping("/{id}")
	public void deleteSupplier(@PathVariable int id) {
		supplierService.daleteSupplier(id);
	}
}
