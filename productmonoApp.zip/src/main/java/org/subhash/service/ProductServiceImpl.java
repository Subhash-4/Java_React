package org.subhash.service;

import java.util.List;

import javax.management.RuntimeErrorException;

import org.springframework.stereotype.Service;
import org.subhash.entity.Product;
import org.subhash.repository.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService {
	
	private ProductRepository productRepository;

	public ProductServiceImpl(ProductRepository productRepository) {
	this.productRepository=productRepository;	
	}

	@Override
	public List<Product> getProducts() {
		// TODO Auto-generated method stub
		return productRepository.findAll();
		}

	@Override
	public Product getProductById(int id) {
		// TODO Auto-generated method stub
		return productRepository.findById(id)
				.orElseThrow(()->new RuntimeException("Product Not found"));
			
	}

	@Override
	public Product addProduct(Product product) {
		// TODO Auto-generated method stub
		return productRepository.save(product);
	}

	@Override
	public Product updateProduct(int id, Product product) {
	Product existingProduct=productRepository.getById(id);
	if(product.getName()!=null) {
		existingProduct.setName(product.getName());
	}
	if(product.getQuantity()!=0) {
		existingProduct.setQuantity(product.getQuantity());
	}
	if(product.getPrice()!=0){
		existingProduct.setPrice(product.getPrice());
	}
	if(product.getSupplier()!=null) {
		existingProduct.setSupplier(product.getSupplier());
		
		
	}
	if(product.getId()!=0) {
		existingProduct.setId(product.getId());
	}
	return productRepository.save(existingProduct);
	}

	@Override
	public void deleteProduct(int id) {
	productRepository.deleteById(id);

	}

	
	

}
