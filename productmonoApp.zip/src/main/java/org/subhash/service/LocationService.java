package org.subhash.service;

import java.util.List;

import org.subhash.entity.Location;

public interface LocationService {
	List<Location>getLocations();
	Location getLocationById(int id);
	Location addLocation(Location location);
	Location updateLocation(int id,Location location);
	void deleteLocation(int id);

}
