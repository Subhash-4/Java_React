package org.subhash.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.subhash.entity.Supplier;
import org.subhash.repository.SupplierRepository;

@Service
public class SupplierServiceImpl implements SupplierService {

	private SupplierRepository supplierRepository;

	public SupplierServiceImpl(SupplierRepository supplierRepository) {
		this.supplierRepository = supplierRepository;
	}

	@Override
	public List<Supplier> getSuppliers() {
		// TODO Auto-generated method stub
		return supplierRepository.findAll();
	}

	// TODO Auto-generated constructor stub

	@Override
	public Supplier getSupplierById(int id) {
		// TODO Auto-generated method stub
		return supplierRepository.findById(id).orElseThrow(() -> new RuntimeException("Supplier not found"));
	}

	@Override
	public Supplier addSupplier(Supplier supplier) {
		// TODO Auto-generated method stub
		return supplierRepository.save(supplier);
	}

	@Override
	public Supplier updateSupplier(int id, Supplier supplier) {
		// TODO Auto-generated method stub
		Supplier existingSupplier = supplierRepository.findById(id)
				.orElseThrow(() -> new RuntimeException("Supplier not found"));
		if (supplier.getSupplierName() != null) {
			existingSupplier.setSupplierName(supplier.getSupplierName());
		}
		return supplierRepository.save(existingSupplier);
	}

	@Override
	public void daleteSupplier(int id) {
		supplierRepository.deleteById(id);

	}
}
