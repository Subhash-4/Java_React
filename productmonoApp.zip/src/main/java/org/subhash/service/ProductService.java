package org.subhash.service;

import java.util.List;

import org.subhash.entity.Product;

public interface ProductService {
	List<Product> getProducts();
	Product getProductById(int id);
	Product addProduct(Product product);
	Product updateProduct(int id,Product product);
	void deleteProduct(int id);

}
