package subhash.com;

import org.junit.jupiter.api.Test;


class EmplyoeeServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
