package subhash.com.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data

public class ApiResponseDto {
	
	private DepartmentDto departmentDto;
	
	private EmployeeDto employeeDto;

	
	public ApiResponseDto(EmployeeDto employeeDto,DepartmentDto departmentDto) {
		this.departmentDto = departmentDto;
		this.employeeDto = employeeDto;
	}

	public DepartmentDto getDepartmentDto() {
		return departmentDto;
	}

	public void setDepartmentDto(DepartmentDto departmentDto) {
		this.departmentDto = departmentDto;
	}

	public EmployeeDto getEmployeeDto() {
		return employeeDto;
	}

	public void setEmployeeDto(EmployeeDto employeeDto) {
		this.employeeDto = employeeDto;
	}
	
}
