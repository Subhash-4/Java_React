package subhash.com.service;
import org.junit.platform.commons.logging.Logger;
import org.junit.platform.commons.logging.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import subhash.com.clients.DepartmentClients;
import subhash.com.dtos.ApiResponseDto;
import subhash.com.dtos.DepartmentDto;
import subhash.com.dtos.EmployeeDto;
import subhash.com.entity.Employee;
import subhash.com.repository.EmployeeRepository;
@Service
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	private EmployeeRepository employeeRepository;
	private DepartmentClients departmentClient;
	public EmployeeServiceImpl(DepartmentClients departmentClient) {
		this.departmentClient = departmentClient;
	}
	Logger logger = LoggerFactory.getLogger(EmployeeServiceImpl.class);
	@Override
	public EmployeeDto saveEmployeeDto(EmployeeDto employeeDto) {
		Employee employee = new Employee(employeeDto.getId(), employeeDto.getFirstName(), 
				employeeDto.getLastName(),
				employeeDto.getEmail(), employeeDto.getDepartmentCode());
		Employee savedEmployee = EmployeeRepository.save(employee);
		return new EmployeeDto(savedEmployee.getId(), savedEmployee.getFirstName(), 
				savedEmployee.getLastName(),
				savedEmployee.getEmail(), savedEmployee.getDepartmentCode());
	}
	@CircuitBreaker(name="${spring.application.name}" ,fallbackMethod="getDepartmentFallback")
	public ApiResponseDto getEmployee(Long id) {
		Employee employee = employeeRepository.findById(id).get();
		EmployeeDto employeeDto = new EmployeeDto(employee.getId(), 
				employee.getFirstName(), employee.getLastName(),
				employee.getEmail(), employee.getDepartmentCode());
		DepartmentDto departmentDto = departmentClient.
				getDepartmentByCode(employee.getDepartmentCode());
		return new ApiResponseDto(employeeDto, departmentDto);
	}
	public ApiResponseDto getDepartmentFallback(Long id,Exception ex) {
		logger.info("getDepartmentFallback method is called with id: "+id);
		Employee employee = employeeRepository.findById(id).get();
		EmployeeDto employeeDto = new EmployeeDto(employee.getId(), 
				employee.getFirstName(), employee.getLastName(),
				employee.getEmail(), employee.getDepartmentCode());
		DepartmentDto departmentDto = new DepartmentDto(
				null, "Department Not Found", "Department Not Found", "Department Not Found");
		return new ApiResponseDto(employeeDto, departmentDto);
	}
}

