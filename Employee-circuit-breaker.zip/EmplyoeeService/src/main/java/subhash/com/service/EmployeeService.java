package subhash.com.service;

import subhash.com.dtos.ApiResponseDto;
import subhash.com.dtos.EmployeeDto;

public interface EmployeeService {
	EmployeeDto saveEmployeeDto(EmployeeDto employeeDto);
	ApiResponseDto getEmployee(Long id);
}
