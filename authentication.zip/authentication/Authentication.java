package com.authentication;

public interface Authentication {
	boolean auth(String username,String password);
}
