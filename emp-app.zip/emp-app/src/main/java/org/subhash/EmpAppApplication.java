package org.subhash;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication

public class EmpAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmpAppApplication.class, args);
	}

}
