package org.subhash.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.subhash.model.Employee;
import org.subhash.service.EmployeeService;

@Controller
public class EmployeeController {
	@Autowired
	private EmployeeService employeeservice;
	@GetMapping("/")
	public String index(Model model) {
	
	
		List<Employee> employees=employeeservice.getAll();
		System.out.println(employees);
		model.addAttribute("employees",employees);
		return "index";
	}
	@GetMapping("/add")
	public String showAdd(Model model) {
	
	Employee employee=new Employee();
	model.addAttribute("Employee",employee);
	return "add";
}
	
}
