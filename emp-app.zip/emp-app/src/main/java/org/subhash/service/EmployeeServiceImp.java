package org.subhash.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.subhash.exception.EmployeeNotFoundException;
import org.subhash.model.Employee;
import org.subhash.repository.EmployeeRepository;
@Service
public class EmployeeServiceImp implements EmployeeService {
	@Autowired
	private EmployeeRepository repository;

	@Override
	public void deleteEmployee(int id) {
		repository.deleteById(id);
		// TODO Auto-generated method stub

	}

	@Override
	public List<Employee> getAll() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

	@Override
	public Employee getById(int id) {
		// TODO Auto-generated method stub
		return repository.findById(id).orElseThrow(()->new EmployeeNotFoundException("Employee with Id"+id+ "does not exist"));
	}
	@Override
	public Employee addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return repository.save(employee);
	}

	@Override
	public Employee updateEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return repository.save(employee);
	}

}
