package org.subhash.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.subhash.model.Employee;


public interface EmployeeRepository extends JpaRepository<Employee, Integer>{

}
