package service;

import static org.mockito.ArgumentMatchers.any;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import subhash.com.entity.Items;
import subhash.com.repository.ItemsRepository;
import subhash.com.service.ItemsServiceImpl;
@ExtendWith(MockitoExtension.class)
class ItemsServiceTest {
	@Mock
	private ItemsRepository repository;
	@InjectMocks
	private ItemsServiceImpl itemsService;
	@Test
	void testGetAllItems() {
		List<Items> items=List.of(
				new Items(1,"Bat",2000,5,"Batting"),
				new Items(2,"Ball",80,8,"Bowling")
				);
		
		when(repository.findAll()).thenReturn(items);
		List<Items> item=itemsService.getAllItems();
		
		assertAll(
				()->assertEquals(item.size(), 2),
				()->assertEquals("Bat",item.get(0).getName())
				);
	}
	@Test
	void testGetByID() {
		Items item=new Items(1,"stump",500,3,"wickets");
		when(repository.findById(1)).thenReturn(Optional.of(item));
		Items items=itemsService.getById(1);
		assertAll(
				()-> assertEquals(items.getId(), 1),
				()->assertEquals(items.getName(), "stump")
				);
	}
	@Test
	void testAddItems() {
		Items item=new Items(1,"Pen",25,10,"writing");
		when(repository.save(item)).thenReturn(item);
		Items items=itemsService.addItems(item);
		assertAll(
				()->assertEquals(items.getPrice(), 25),
				()->assertNotNull(items)
				);
	}
	@Test
	void testUpdateItems() {
		Items item=new Items(1,"laptop",40000,3,"coding");
		Items items=new Items(0,null,50000,0,null);
		when(repository.findById(1)).thenReturn(Optional.of(item));
		when(repository.save(any(Items.class))).thenReturn(item);
		Items itemss=itemsService.updateItems(1, items);
		assertAll(
				()->assertEquals(itemss.getName(), "laptop"),
				()->assertEquals(itemss.getPrice(), 50000)
				);
	}
	@Test
	void testDeleteItems() {
		Items item=new Items(1,"king",100000,1,"crown");
		when(repository.findById(1)).thenReturn(Optional.of(item));
		itemsService.deleteItems(1);
		verify(repository,times(1)).deleteById(1);
	}
	

}
