package subhash.com.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import subhash.com.entity.Items;
import subhash.com.exception.ItemsNotFoundException;
import subhash.com.repository.ItemsRepository;
@Service
public class ItemsServiceImpl implements ItemsService {
	@Autowired
	private ItemsRepository repository;
	
	@Override
	public List<Items> getAllItems() {
		
		return repository.findAll();
	}

	@Override
	public Items getById(int id) {
		return repository.findById(id).orElseThrow(()->new ItemsNotFoundException("Items with id "+ id+" Not found"));
	}

	@Override
	public Items addItems(Items items) {
		// TODO Auto-generated method stub
		return repository.save(items);
	}

	@Override
	public void deleteItems(int id) {
		Optional<Items> optItems=repository.findById(id);
		if(!optItems.isPresent()) {
			throw new ItemsNotFoundException("Items with id "+id+" not found");
		}
		repository.deleteById(id);

	}

	@Override
	public Items updateItems(int id, Items items) {
		// TODO Auto-generated method stub
		Optional<Items> optItems=repository.findById(id);
		if(!optItems.isPresent()) {
			throw new ItemsNotFoundException("Items with id "+id+" not found");
		}
		Items item=optItems.get();
		if(items.getName()!=null) {
			item.setName(items.getName());
		}
		if(items.getPrice()!=0) {
			item.setPrice(items.getPrice());
		}
		if(items.getQuantity()!=0) {
			item.setQuantity(items.getQuantity());
		}
		if(items.getDescription()!=null) {
			item.setDescription(items.getDescription());
		}
		return repository.save(item);
	}

	@Override
	public List<Items> getByName(String name) {
		// TODO Auto-generated method stub
		return repository.findByName(name);
	}

	@Override
	public List<Items> getByPrice(double price) {
		// TODO Auto-generated method stub
		return repository.findByPriceGreaterThan(price);
	}
}
