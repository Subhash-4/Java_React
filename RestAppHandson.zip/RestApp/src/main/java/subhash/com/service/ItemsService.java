package subhash.com.service;

import java.util.List;

import subhash.com.entity.Items;

public interface ItemsService {
	List<Items>getAllItems();
	Items getById(int id);
	Items addItems(Items items);
	Items updateItems(int id,Items items);
	void deleteItems(int id);
	List<Items> getByName(String name);
	List<Items> getByPrice(double price);
	
}
