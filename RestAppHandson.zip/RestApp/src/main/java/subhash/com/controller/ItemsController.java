package subhash.com.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;
import subhash.com.entity.Items;
import subhash.com.service.ItemsService;
@RestController
@RequestMapping("/api/items")
public class ItemsController {
	@Autowired
	private ItemsService itemsService;
	@GetMapping
	public ResponseEntity<List<Items>> getAll(){
		List<Items> items=itemsService.getAllItems();
		return ResponseEntity.ok(items);
	}
	@GetMapping("/{id}")
	public ResponseEntity<Items> getById(@PathVariable int id){
		Items items=itemsService.getById(id);
		return new ResponseEntity<Items>(items,HttpStatus.OK);
	}
	@PostMapping
	@ResponseStatus(HttpStatus.CREATED)
	public Items addItems(@Valid @RequestBody Items items) {
		return itemsService.addItems(items);
	}
	@PutMapping("/{id}")
	public Items updateItems(@PathVariable int id,@Valid @RequestBody Items items) {
		return itemsService.updateItems(id, items);
	}
	@DeleteMapping("/{id}")
	public ResponseEntity<Items> deleteItems(@PathVariable int id){
		itemsService.deleteItems(id);
		return ResponseEntity.noContent().build();
	}
	@GetMapping("/name/{name}")
	public List<Items> findByName(@PathVariable String name){
		return itemsService.getByName(name);
	}
	@GetMapping("/price/{price}")
	public List<Items> findByPrice(@PathVariable double price){
		return itemsService.getByPrice(price);
	}
}
