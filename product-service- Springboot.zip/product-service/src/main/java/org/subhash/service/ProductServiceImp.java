package org.subhash.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.subhash.entity.Product;
import org.subhash.repositpry.ProductRepository;

@Service

public class ProductServiceImp implements ProductService {

	@Autowired
	private ProductRepository productRepository;

	@Override
	public List<Product> getAllProduct() {
		// TODO Auto-generated method stub
		return productRepository.findAll();
	}

	@Override
	public Product getById(int id) {
		// TODO Auto-generated method stub
		return productRepository.findById(id)
				.orElseThrow(() -> new ProductNotFoundException("Product with Id " + id + "not found"));
	}

	@Override
	public Product addProduct(Product product) {
		// TODO Auto-generated method stub
		return productRepository.save(product);
	}

	@Override
	public Product updateProduct(int id, Product product) {
		Optional<Product> otpproduct = productRepository.findById(id);
		if (!otpproduct.isPresent()) {
			throw new ProductNotFoundException("Product with Id " + id + "not found");
		}
		product.setId(id);
		return productRepository.save(product);
	}

	@Override
	public void deleteProduct(int id) {
		Optional<Product> otpproduct = productRepository.findById(id);
		if (!otpproduct.isPresent()) {
			throw new ProductNotFoundException("Product with Id " + id + "not found");

		}
		productRepository.deleteById(id);

	}

}
