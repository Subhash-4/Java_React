INSERT INTO product (name, price) VALUES ('Product1', 10.0);
INSERT INTO product (name, price) VALUES ('Product2', 20.0);
