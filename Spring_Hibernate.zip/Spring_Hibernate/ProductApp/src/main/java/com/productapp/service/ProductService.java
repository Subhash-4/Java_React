package com.productapp.service;

import com.productapp.model.Product;
import java.util.List;

public interface ProductService {
    void saveProduct(Product product);
    List<Product> getAllProducts();
    Product getProductById(int id);
    void updateProduct(Product product);
    void deleteProduct(int id);
}
