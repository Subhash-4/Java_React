package com.java.test;

public class InvalidInputError extends RuntimeException {

	public InvalidInputError() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidInputError(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
