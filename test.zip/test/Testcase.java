package com.java.test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

class Testcase {
	Person person;
	
	@Before
	@Test
	void init() {
		Person person = new Person("Subhash","Adithya");
	}
	@Test
	void getFullName() {
		String full=person.getFirstName() + person.getLastName();
		assertEquals("SubhashAdithya", full);
	}
	@Test 
	void firstName(){
		String first=person.getFirstName();
		assertEquals("Subhash",first);
	}
	@Test
	void lastName() {
		String last=person.getLastName();
		assertEquals("Adithya", last);
	}

}
