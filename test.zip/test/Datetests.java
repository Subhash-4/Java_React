package com.java.test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

class Datetests {
	DateTest date;
	
	@Before
	@Test
	void init() {
		date=new DateTest(06,03,2024);
	}

	@Test
	void getDay() {
		int day=date.getDay();
		assertEquals(06, day);
		
	}
	@Test
	void getMonth() {
		int month=date.getMonth();
		assertEquals(03, month);
		
	}
	@Test
	void getYear() {
		int year=date.getYear();
		assertEquals(2024, year);
		
	}
	
	

}
