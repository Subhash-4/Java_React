package com.java.test;

import java.util.Scanner;

public class Person {
    private String firstName;
    private String lastName;

    public Person(String fname, String lname) {
        if (fname == null && lname == null) {
            throw new InvalidInputError("Both Names Cannot be NULL");
        }
        this.firstName = fname;
        this.lastName = lname;
    }
    public String getFirstName() {
        return this.firstName;
    }

    public String getLastName() {
        return this.lastName;
    }

    public String getFullName() {
        String first = (this.firstName != null) ? this.firstName : "?";
        String last = (this.lastName != null) ? this.lastName : "?";
        if (first==null || last==null) {
        	throw new InvalidInputError("give valid input");
        }
        return first + " " + last;
    }

   

    public static void main(String[] args) {
    	Scanner sc=new Scanner(System.in);
    	System.out.println("first name");
    	String fname=sc.nextLine();
    	System.out.println("last name");
    	String lname=sc.nextLine();
    	sc.close();
    	
    	if(fname==null || lname==null) {
    		throw new InvalidInputError("give valid input");
    	}
        Person p = new Person(fname, lname);
        System.out.println("First Name: " + p.getFirstName());
        System.out.println("Last Name: " + p.getLastName());
        System.out.println("Full Name: " + p.getFullName());
    }
}

