package com.productApp.service;

import java.util.Collection;

import com.productApp.dao.Product;

public interface ProService {
	
	Collection<Product>getAll();
	Product getById(int id);
	String addProduct(Product product);
	String updateProduct(Product product);
	String deleteProduct(int id);

}
