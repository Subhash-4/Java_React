package com.productApp.dao;
import java.util.Collection;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Map;


public class ProductDaoImpl implements ProductDao{
	

	private static Map<Integer,Product> prDb=new HashMap<>();
	
	public ProductDaoImpl() {
		prDb.put(1,new Product(1,"mango",300,100,"badami mango",new GregorianCalendar(2024,01,15).getTime()));
		prDb.put(2,new Product(2,"apple",200,100,"kashmir apple",new GregorianCalendar(2024,04,13).getTime()));
	}
	

	@Override
	public Collection<Product> getAll() {
		// TODO Auto-generated method stub
		return prDb.values();
	}

	@Override
	public Product getById(int id) {
		// TODO Auto-generated method stub
		Product pr=prDb.get(id);
		if(pr==null) {
			System.out.println("product "+id +"doesnot exist");
		}
		return pr;
	}

	@Override
	public String addProduct(Product product) {
		// TODO Auto-generated method stub
		prDb.put(product.getId(), product);
		
		return "product "+product.getId()+"added successfully";
	}

	@Override
	public String updateProduct(Product product) {
		// TODO Auto-generated method stub
		Product pro=prDb.get(product.getId());
		pro.setPname(product.getPname());
		pro.setPrice(product.getPrice());
		pro.setQuantity(product.getQuantity());
		pro.setDescription(product.getDescription());
		pro.setOrdDate(product.getOrdDate());
		return "product "+product.getId()+" upload successfully";
	}

	@Override
	public String deleteProduct(int id) {
		// TODO Auto-generated method stub
		prDb.remove(id);
		return "product "+id +"deleted";
	}



}
