package com.arithemetic;

public interface ArithmeticOperation {
	double operate(double a,double b);
}
