package com.java.stringReverse;

 
	public interface Javainterface {
		String StringOperate(String s);
	}


