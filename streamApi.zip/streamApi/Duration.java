package com.java.streamApi;


import java.util.List;

public class Duration {
	public static void main(String[] args) {
		List<Employee> employee=Employee.createEmployee();
		employee.forEach(e->System.out.println(e));
		employee.forEach(e ->
              System.out.println(e.getFirstName() + " " + e.getLastName() + " - Service duration: " + e.getServiceDuration()));

	}
}
