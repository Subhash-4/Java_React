package com.java.streamApi;

import java.util.List;
import java.util.Scanner;

public class IncreaseSalary {
	public static void main(String[] args) {
	List<Employee> employee=Employee.createEmployee();
	Scanner sc=new Scanner(System.in);
	System.out.println("enter increment");
	double increment=sc.nextDouble();
	employee.forEach(e->System.out.println("name of employee "+e.getFirstName()+" salary "+e.getSalary()
	+" salary increment "+e.getSalaryIncrement(increment)));
	}
	
}
