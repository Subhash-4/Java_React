package com.java.streamApi;

import java.util.Comparator;
import java.util.List;

public class SeniorEmployee {
	public static void main(String[] args) {
		List<Employee> employee=Employee.createEmployee();
		employee.forEach(e->System.out.println(e));
		 Employee seniorMostEmployee = employee.stream()
	                .max(Comparator.comparing(Employee::getHireDate))
	                .orElseThrow(null); 
	        System.out.println("Senior most employee: " + seniorMostEmployee.getFirstName() + " " + seniorMostEmployee.getLastName()+" "
	        		+seniorMostEmployee.getHireDate());
	}
}
