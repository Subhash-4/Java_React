package org.subhash.repository;

import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.subhash.model.Product;

public interface ProductRepository extends ReactiveCrudRepository<Product,Integer>{

}
