package org.subhash.contrpller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.subhash.model.Product;
import org.subhash.service.Productservice;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import org.springframework.web.bind.annotation.RequestParam;

@RestController
@RequestMapping("/products")

public class Productcontroller {
	private final Productservice productService;
	

	public Productcontroller(Productservice productService) {
		this.productService = productService;
	}

	@GetMapping
	public Flux<Product> getAllProducts() {
		return productService.getProduct();
	}

	@GetMapping("{id}")
	public String getMethodName(@RequestParam String param) {
		return new String();
	}

	public Mono<Product> getProduct(@PathVariable int id) {
		return productService.getProduct(id);
	}

@PostMapping
public Mono<ResponseEntity<Product>>createProduct(@RequestBody Product product){
	return productService.createProduct(product)
			.map(createProduct->ResponseEntity.created("/products" +createdProduct.getId()))
			.body(createdProduct));
}

@PutMapping("/{id}")
public Mono<Product>update(@PathVariable int id ,@RequestBody Product product){
	return productService.updateProduct(id, product);
}


@DeleteMapping("/{id}")
public Mono<Void> deleteProduct(@PathVariable int id){
	return productService.deleteProduct(id);

}
	
}
