package org.subhash.service;



import org.subhash.model.Product;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface Productservice {
	Flux<Product>getProduct();
	Mono<Product>getProduct(int id);
	Mono<Product>createProduct(Product product);
	Mono<Product>updateProduct(int id,Product product);
	Mono<Void> deleteProduct(int id);

}
