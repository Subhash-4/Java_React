package org.subhash.service;

import java.util.function.Function;

import org.springframework.stereotype.Service;
import org.subhash.exception.ProductNotFoundException;
import org.subhash.model.Product;
import org.subhash.repository.ProductRepository;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class ProductServiceImp implements Productservice {
	private ProductRepository productRepository;

	public ProductServiceImp(ProductRepository productRepository) {
		this.productRepository = productRepository;
	}

	@Override
	public Flux<Product> getProduct() {
		// TODO Auto-generated method stub
		return productRepository.findAll();

	}

	@Override
	public Mono<Product> getProduct(int id) {
		// TODO Auto-generated method stub
	      return productRepository.findById(id)
		.switchIfEmpty(Mono.error(new ProductNotFoundException("Product with id "+id+"does not exist")));
	}

	@Override
	public Mono<Product> createProduct(Product product) {
		// TODO Auto-generated method stub
		return productRepository.save(product);

	}

	@Override
	public Mono<Product> updateProduct(int id, Product product) {
		// TODO Auto-generated method stub
		Mono<Product>productMono=productRepository.findById(id)
				.switchIfEmpty(Mono.error(new ProductNotFoundException("Product with id"+id+" does not exist")));
		var updatedProduct=productMono.map(products->{
			if(product.getName()!=null) {
				products.setName(product.getName());
			}
			if (product.getQuantity()!=0) {
				products.setQuantity(product.getQuantity());
			}
			if(product.getPrice()!=0) {
				products.setPrice(product.getPrice());
			}
			return productRepository.save(products);
		});
		return updatedProduct.flatMap(Function.identity());
	}

	@Override
	public Mono<Void> deleteProduct(int id) {
		// TODO Auto-generated method stub
		productRepository.findById(id)
				.switchIfEmpty(Mono.error(new ProductNotFoundException("Product with id" + id + " does not exist")));
		return productRepository.deleteById(id);
	}

}
